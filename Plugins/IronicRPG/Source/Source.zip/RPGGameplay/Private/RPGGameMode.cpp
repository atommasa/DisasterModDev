// Copyright Ironic Studio. All Rights Reserved.


#include "RPGGameMode.h"
#include "EngineUtils.h"
#include "RPGSettings.h"

#include "SaveGame/RPGSaveGameMetadata.h"

#include "Widgets/WidgetBase.h"
#include "Components/UIControlComponent.h"

#include "Misc/SpawnablePoint.h"

DEFINE_LOG_CATEGORY(LogRPGGameMode);

void ARPGGameMode::InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage)
{
	Super::InitGame(MapName, Options, ErrorMessage);

	SaveSubsystem = GetGameInstance()->GetSubsystem<USaveGameSubsystem>();
	check(SaveSubsystem);
	SaveGameLoadDelegateHandle = SaveSubsystem->OnSaveGameLoadCompleted.AddUObject(this, &ARPGGameMode::OnSaveGameLoaded);

	GameZoneSubsystem = GetGameInstance()->GetSubsystem<UGameZoneSubsystem>();
	check(GameZoneSubsystem);

	LoadingScreenSubsystem = ULoadingScreenSubsystem::Get(this);
	check(LoadingScreenSubsystem);
	// TODO: Maybe use more fliexible event binding (e.g., BlueprintImplementableEvent)
	LoadingScreenSubsystem->OnLoadingScreenStop.AddUniqueDynamic(this, &ARPGGameMode::OnStoppedLoading);
	UE_LOG(LogRPGGameMode, Log, TEXT("[LoadingScreen] Bound stop callback to GameMode."));

	CharacterSubsystem = GetGameInstance()->GetSubsystem<UCharacterSubsystem>();
	check(CharacterSubsystem);
	PartyConstructedDelegateHandle = CharacterSubsystem->OnPartyConstructed.AddUObject(this, &ARPGGameMode::OnPartyReady);
}

void ARPGGameMode::BeginPlay()
{
	Super::BeginPlay();

	CreateMainMenuWidget();
}

void ARPGGameMode::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (SaveSubsystem && SaveGameLoadDelegateHandle.IsValid())
	{
		SaveSubsystem->OnSaveGameLoadCompleted.Remove(SaveGameLoadDelegateHandle);
		SaveGameLoadDelegateHandle.Reset();
	}

	if (CharacterSubsystem && PartyConstructedDelegateHandle.IsValid())
	{
		CharacterSubsystem->OnPartyConstructed.Remove(PartyConstructedDelegateHandle);
		PartyConstructedDelegateHandle.Reset();
	}

	if (LoadingScreenSubsystem)
	{
		LoadingScreenSubsystem->OnLoadingScreenStop.RemoveDynamic(this, &ARPGGameMode::OnStoppedLoading);
	}

	Super::EndPlay(EndPlayReason);
}

ARPGGameMode* ARPGGameMode::GetRPGGameMode(UObject* WorldContextObject)
{
	if (!WorldContextObject)
	{
		return nullptr;
	}

	return Cast<ARPGGameMode>(UGameplayStatics::GetGameMode(WorldContextObject));
}

void ARPGGameMode::StartGameSession(const FString& SlotName)
{
	LoadingScreenSubsystem->StartLoadingScreen();

	SaveSubsystem->LoadGame(SlotName);

	if (APlayerController* PC = UGameplayStatics::GetPlayerController(this, 0))
	{
		if (UUIControlComponent* UIComp = PC->GetComponentByClass<UUIControlComponent>())
		{
			UIComp->CloseAllMenus();
		}
	}
}

void ARPGGameMode::RequestTeleportTo(const FGameZoneContext& NewGameZoneContext)
{
	LoadingScreenSubsystem->StartLoadingScreen();
	
	GameZoneSubsystem->EnterGameZone(NewGameZoneContext, TDelegate<void()>::CreateLambda([this]()
		{
			CharacterSubsystem->SpawnPartyMembers(
				GameZoneSubsystem->GetSaveGameTransform(),
				true,
				ESpawnPartyMode::KeepControlSameCharacter
			);
		}));
}

void ARPGGameMode::AwakenSpawnablePoints()
{
	for (TActorIterator<ASpawnablePoint> It(GetWorld()); It; ++It)
	{
		ASpawnablePoint* SpawnPoint = *It;
		if (SpawnPoint && SpawnPoint->CanSpawnOnLevelLoaded())
		{
			SpawnPoint->Awaken();
		}
	}
}

void ARPGGameMode::OnSaveGameLoaded_Implementation()
{
	UE_LOG(LogRPGGameMode, Log, TEXT("[LoadGame] Save providers completed; spawning party."));

	// Awaken spawn points
	AwakenSpawnablePoints();

	// Spawn party members
	CharacterSubsystem->SpawnPartyMembers(
		GameZoneSubsystem->GetSaveGameTransform(),
		true,
		ESpawnPartyMode::ByPlayerPartyIndex
	);
}

void ARPGGameMode::CreateMainMenuWidget_Implementation()
{
	if (APlayerController* PC = UGameplayStatics::GetPlayerController(this, 0))
	{
		if (UUIControlComponent* UIComp = PC->GetComponentByClass<UUIControlComponent>())
		{
			MainMenuWidget = UIComp->PushWidget(ERPGUILayer::Menu, MainMenuWidgetClass, FRPGUIOpenArgs());
		}
	}
}

void ARPGGameMode::OnStoppedLoading_Implementation()
{
	UE_LOG(LogRPGGameMode, Log, TEXT("[LoadingScreen] Stop callback received; restoring gameplay control."));
	// TODO: ���ӱĥΧ�n���覡��������A
	if (ARPGPlayerController* PC = Cast<ARPGPlayerController>(UGameplayStatics::GetPlayerController(this, 0)))
	{
		PC->SetControlMode(ERPGControlMode::Gameplay);
	}

	UGameplayStatics::SetGamePaused(this, false);
}

void ARPGGameMode::OnPartyReady()
{
	UE_LOG(LogRPGGameMode, Log, TEXT("[LoadGame] Party ready. PlayerIndex=%d Character=%s"),
		CharacterSubsystem ? CharacterSubsystem->PlayerPartyIndex : INDEX_NONE,
		*GetNameSafe(CharacterSubsystem ? CharacterSubsystem->GetPlayerCharacter() : nullptr));

	// Possess the player character
	if (ABaseCharacter* CurrentCharacter = CharacterSubsystem->GetPlayerCharacter())
	{
		if (ARPGPlayerController* PC = Cast<ARPGPlayerController>(UGameplayStatics::GetPlayerController(this, 0)))
		{
			// TODO: ���ӻݭn���Y�ԨM�w�ާ@�Ҧ�
			if (LoadingScreenSubsystem->IsLoading())
			{
				PC->PossessCharacterWithMode(CurrentCharacter, ERPGControlMode::None);
			}
			else
			{
				PC->PossessCharacter(CurrentCharacter);
			}
		}
	}
	else
	{
		UE_LOG(LogRPGGameMode, Warning, TEXT("No player character found in CharacterSubsystem!"));
	}

	LoadingScreenSubsystem->StopLoadingScreen();
}
