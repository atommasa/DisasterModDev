// Copyright Ironic Studio. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"

#include "Assets/RPGAssetManager.h"
#include "Kismet/GameplayStatics.h"

#include "SaveGameSubsystem.h"
#include "SaveGame/RPGSaveGame.h"

#include "CharacterSubsystem.h"
#include "Characters/BaseCharacter.h"

#include "GameZoneSubsystem.h"

#include "LoadingScreenSubsystem.h"

#include "RPGGameMode.generated.h"

DECLARE_LOG_CATEGORY_EXTERN(LogRPGGameMode, Log, All);

/**
 * The base game mode for the Ironic RPG plugin.
 */
UCLASS()
class RPGGAMEPLAY_API ARPGGameMode : public AGameModeBase
{
	GENERATED_BODY()

protected:
	virtual void InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage) override;
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

public:
	UFUNCTION(BlueprintPure, Category = "RPG|Game", meta=(WorldContext = "WorldContextObject"))
	static ARPGGameMode* GetRPGGameMode(UObject* WorldContextObject);

	// Start the game from the menu
	UFUNCTION(BlueprintCallable, Category = "RPG|Game")
	virtual void StartGameSession(const FString& SlotName = TEXT(""));

	UFUNCTION(BlueprintCallable, Category = "RPG|Game")
	virtual void RequestTeleportTo(const FGameZoneContext& NewGameZoneContext);

	UFUNCTION(BlueprintCallable, Category = "RPG|Game")
	virtual void AwakenSpawnablePoints();

protected:
	// Called after a save game is loaded
	UFUNCTION(BlueprintNativeEvent)
	void OnSaveGameLoaded();
	virtual void OnSaveGameLoaded_Implementation();

	UPROPERTY(BlueprintReadOnly, Category = "RPG|Game")
	USaveGameSubsystem* SaveSubsystem;

protected:
	UPROPERTY(BlueprintReadOnly, Category = "RPG|Game")
	UGameZoneSubsystem* GameZoneSubsystem;

protected:
	UFUNCTION(BlueprintNativeEvent, Category = "RPG|MainMenu")
	void CreateMainMenuWidget();
	virtual void CreateMainMenuWidget_Implementation();

	// Called when the menu is initialized
	UFUNCTION(BlueprintImplementableEvent, Category = "RPG|MainMenu")
	void OnMainMenuInitialized();

	UPROPERTY(EditDefaultsOnly, Category = "MainMenu")
	TSubclassOf<class UWidgetBase> MainMenuWidgetClass;

	UPROPERTY(BlueprintReadWrite, Category = "RPG|MainMenu")
	TWeakObjectPtr<class UWidgetBase> MainMenuWidget;

protected:
	UPROPERTY(BlueprintReadOnly, Category = "RPG|LoadingScreen")
	ULoadingScreenSubsystem* LoadingScreenSubsystem;

	UFUNCTION(BlueprintNativeEvent, Category = "RPG|LoadingScreen")
	void OnStoppedLoading();
	virtual void OnStoppedLoading_Implementation();

protected:
	UPROPERTY(BlueprintReadOnly, Category = "RPG|Character")
	UCharacterSubsystem* CharacterSubsystem;

	UFUNCTION()
	void OnPartyReady();

	FDelegateHandle SaveGameLoadDelegateHandle;
	FDelegateHandle PartyConstructedDelegateHandle;

};
