// Copyright Ironic Studio. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Levels/MapMarkerData.h"
#include "MapMarkerComponent.generated.h"

DECLARE_MULTICAST_DELEGATE_OneParam(FOnMapMarkerComponentRegistered, UMapMarkerComponent*);
DECLARE_MULTICAST_DELEGATE_OneParam(FOnMapMarkerComponentUnregistered, UMapMarkerComponent*);

class RPGCORE_API FMapMarkerDelegates
{
public:
    static FOnMapMarkerComponentRegistered OnRegistered;
    static FOnMapMarkerComponentUnregistered OnUnregistered;
};

UCLASS( ClassGroup=(Map), meta=(BlueprintSpawnableComponent) )
class RPGCORE_API UMapMarkerComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UMapMarkerComponent(const FObjectInitializer& ObjectInitializer);

protected:
	virtual void BeginPlay() override;
    virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

public:
    UPROPERTY(VisibleAnywhere, Category = "Marker")
    FGuid MarkerId = FGuid::NewGuid();

    UPROPERTY(EditAnywhere, Category = "Marker")
    FMapMarkerData MarkerData;

#if WITH_EDITORONLY_DATA
    UPROPERTY(EditAnywhere, Category = "Marker")
    bool bBakeMarker = false;
#endif // WITH_EDITORONLY_DATA

};
