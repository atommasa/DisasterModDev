// Copyright Ironic Studio. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "NativeGameplayTags.h"
#include "GameplayTagContainer.h"
#include "Assets/RPGPrimaryAsset.h"
#include "MapMarkerData.generated.h"

UE_DECLARE_GAMEPLAY_TAG_EXTERN(Marker_Type)

UENUM(BlueprintType)
enum class EMapMarkerState : uint8
{
    Activated,
    Deactivated,
    Hide,
};

UENUM(BlueprintType, meta=(Bitflags))
enum class EMapMarkerDisplayMode : uint8
{
    None = 0,
    WorldMap = 1 << 0,
    MiniMap = 1 << 1
};

ENUM_CLASS_FLAGS(EMapMarkerDisplayMode);

/**
 * This struct is used to store data about map markers, which can be used to display markers on the map or minimap.
 * It contains information about the marker type, its world location, and a reference to an asset that can be used to display the marker.
 */
USTRUCT(BlueprintType)
struct RPGCORE_API FMapMarkerData
{
	GENERATED_BODY()

public:
    UPROPERTY(BlueprintReadOnly)
    FGuid MarkerId;

    UPROPERTY(BlueprintReadOnly)
    FRPGId ZoneId;

    UPROPERTY(BlueprintReadOnly, Transient)
    TWeakObjectPtr<class UMapMarkerComponent> SourceComponent = nullptr;

    UPROPERTY(BlueprintReadOnly, Transient)
    bool bHasBakedData = false;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, meta=(Categories = "Map.Marker"))
    FGameplayTagContainer MarkerType;

    UPROPERTY(EditAnywhere, BlueprintReadOnly)
    EMapMarkerState MarkerState = EMapMarkerState::Activated;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, meta=(Bitmask, BitmaskEnum = "/Script/RPGCore.EMapMarkerDisplayMode"))
    int32 DisplayMode;

    UPROPERTY(EditAnywhere, BlueprintReadOnly)
    FText DisplayName;

    UPROPERTY(EditAnywhere, BlueprintReadOnly)
    FText Description;

    UPROPERTY(EditAnywhere, BlueprintReadOnly)
    FRPGId ReferenceAssetId;

    UPROPERTY(EditAnywhere, BlueprintReadOnly)
    bool bCanTeleport = false;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, meta=(EditCondition = "bCanTeleport", EditConditionHides))
    FGameplayTag EntryTag;

	UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly)
	FVector WorldLocation;

};

USTRUCT(BlueprintType)
struct RPGCORE_API FMapMarkerStyle
{
    GENERATED_BODY()

    UPROPERTY(BlueprintReadOnly)
    TSoftObjectPtr<UTexture2D> Icon;

    UPROPERTY(EditAnywhere)
    FLinearColor Tint = FLinearColor::White;

    UPROPERTY(EditAnywhere)
    int32 ZOrder = 0;

};