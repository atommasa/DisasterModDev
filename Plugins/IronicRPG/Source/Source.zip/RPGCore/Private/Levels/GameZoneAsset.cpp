// Copyright Ironic Studio. All Rights Reserved.


#include "Levels/GameZoneAsset.h"

#if WITH_EDITOR

#include "EngineUtils.h"
#include "UObject/SavePackage.h"
#include "Levels/MapMarkerComponent.h"

void UGameZoneAsset::BakeMapMarkers()
{
    if (!GetId().IsValid())
    {
        UE_LOG(LogTemp, Warning, TEXT("[MapBake] ZoneAsset '%s' has no valid id."), *GetName());
        return;
    }

    if (LevelToLoad.IsNull())
    {
        UE_LOG(LogTemp, Warning, TEXT("[MapBake] ZoneAsset '%s' has no LevelToLoad."), *GetName());
        return;
    }

    UWorld* TargetWorld = LevelToLoad.LoadSynchronous();

    if (!IsValid(TargetWorld))
    {
        UE_LOG(LogTemp, Error,
            TEXT("[MapBake] Failed to load world for ZoneAsset '%s': %s"),
            *GetName(),
            *LevelToLoad.ToSoftObjectPath().ToString());

        return;
    }

    Modify();

    TArray<FMapMarkerData> NewMarkers;

    for (TActorIterator<AActor> ActorIt(TargetWorld); ActorIt; ++ActorIt)
    {
        AActor* Actor = *ActorIt;

        if (!IsValid(Actor) || Actor->IsTemplate())
        {
            continue;
        }

        TInlineComponentArray<UMapMarkerComponent*> MarkerComponents;
        Actor->GetComponents(MarkerComponents);

        for (UMapMarkerComponent* MarkerComponent : MarkerComponents)
        {
            if (!IsValid(MarkerComponent) || !MarkerComponent->bBakeMarker)
            {
                continue;
            }

            FMapMarkerData MarkerData = MarkerComponent->MarkerData;
            MarkerData.MarkerId = MarkerComponent->MarkerId;
            MarkerData.ZoneId = GetId();
            MarkerData.bHasBakedData = true;
            MarkerData.WorldLocation = Actor->GetActorLocation();

            if (!MarkerData.MarkerType.IsValid())
            {
                UE_LOG(LogTemp, Warning,
                    TEXT("[MapBake] Marker on Actor '%s' has invalid MarkerType. Skipped."),
                    *GetNameSafe(Actor));

                continue;
            }

            NewMarkers.Add(MoveTemp(MarkerData));
        }
    }

    NewMarkers.Sort([](
        const FMapMarkerData& A,
        const FMapMarkerData& B)
        {
            return A.MarkerType.ToString() < B.MarkerType.ToString();
        });

    BakedMapMarkers = MoveTemp(NewMarkers);

    MarkPackageDirty();

    UE_LOG(LogTemp, Log,
        TEXT("[MapBake] Zone '%s' baked %d markers."),
        *GetName(),
        BakedMapMarkers.Num());
}

#endif