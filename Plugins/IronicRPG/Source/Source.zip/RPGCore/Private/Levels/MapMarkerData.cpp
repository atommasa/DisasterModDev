// Copyright Ironic Studio. All Rights Reserved.


#include "Levels/MapMarkerData.h"

UE_DEFINE_GAMEPLAY_TAG_COMMENT(Marker_Type, "Map.Marker", "This tag is used to define the type of the map marker, such as quest marker, point of interest, etc.")
