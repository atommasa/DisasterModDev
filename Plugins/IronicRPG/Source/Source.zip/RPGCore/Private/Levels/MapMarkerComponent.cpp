// Copyright Ironic Studio. All Rights Reserved.


#include "Levels/MapMarkerComponent.h"

FOnMapMarkerComponentRegistered FMapMarkerDelegates::OnRegistered;
FOnMapMarkerComponentUnregistered FMapMarkerDelegates::OnUnregistered;

UMapMarkerComponent::UMapMarkerComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryComponentTick.bCanEverTick = false;
	
}

void UMapMarkerComponent::BeginPlay()
{
	Super::BeginPlay();

	FMapMarkerDelegates::OnRegistered.Broadcast(this);
}

void UMapMarkerComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	FMapMarkerDelegates::OnUnregistered.Broadcast(this);

	Super::EndPlay(EndPlayReason);
}


