// Copyright Ironic Studio. All Rights Reserved.


#include "CharacterSubsystem.h"
#include "RPGSettings.h"
#include "SaveGameSubsystem.h"
#include "Kismet/GameplayStatics.h"

#include "Characters/Attributes/RPGAttributeSet.h"
#include "Characters/Components/CharacterAbilitySystemComponent.h"
#include "Characters/CharacterControlComponent.h"
#include "Characters/Components/CombatComponent.h"

#include "Camera/RPGPlayerCameraManager.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"

#include "CharacterSaveModule.h"
#include "SaveGame/RPGSaveGame.h"

#include "Helpers/RPGHelperMacros.h"
#include "Assets/RPGAssetLibrary.h"

DEFINE_LOG_CATEGORY(LogCharacterSubsystem);

void UCharacterSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	
	// Load settings
	const URPGSettings* Settings = URPGSettings::GetRPGSettings();
	if (!Settings)
	{
		return;
	}

	MaxPartyMembers = Settings->MaxPartyMembers;
}

void UCharacterSubsystem::Deinitialize()
{
	ClearPartyInitializationTracking();

	// Clean up all character instances
	for (TPair<FGuid, TObjectPtr<ABaseCharacter>> Pair : InstanceCharacters)
	{
		if (Pair.Value)
		{
			UE_LOG(LogCharacterSubsystem, Log, TEXT("Destroying character instance: %s"), *Pair.Value->GetName());
			Pair.Value->Destroy();
		}
	}

	InstanceCharacters.Empty();
}

void UCharacterSubsystem::SaveCharacterDataToMap(ABaseCharacter* Instance)
{
	if (Instance && CharacterDataMap.Contains(Instance->GetId()))
	{
		FCharacterSaveData Data = Instance->GetCharacterData();
		Data.bIsSaveData = true; // Mark as save data

		CharacterDataMap[Instance->GetId()] = Data;
	}
}

void UCharacterSubsystem::SavePartyMembersDataToMap()
{
	for (const FGuid& Guid : PartyMemberGuids)
	{
		SaveCharacterDataToMap(InstanceCharacters.FindRef(Guid));
	}
}

void UCharacterSubsystem::ModifyCharactersData(const TArray<FRPGId>& Ids, UGameplayEffect* Effect, const float Level)
{
	if (!Effect)
	{
		return;
	}

	ABaseCharacter* TempOwner = nullptr;

	for (const FRPGId& Id : Ids)
	{
		if (!CharacterDataMap.Contains(Id))
		{
			continue;
		}

		int32 InstanceIndex = PartyMemberIds.IndexOfByKey(Id);
		if (PartyMemberGuids.IsValidIndex(InstanceIndex))
		{
			if (ABaseCharacter* Instance = InstanceCharacters.FindRef(PartyMemberGuids[InstanceIndex]))
			{
				Instance->AbilitySystemComponent->ApplyGameplayEffectToSelf(Effect, Level, Instance->AbilitySystemComponent->MakeEffectContext());
				continue;
			}
		}

		if (!TempOwner)
		{
			FActorSpawnParameters Params;
			Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
			TempOwner = GetWorld()->SpawnActor<ABaseCharacter>(PlayableCharacterClass, Params);
			TempOwner->PrimaryActorTick.bCanEverTick = false; // Disable ticking for performance
			TempOwner->GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::NoCollision); // Disable collision
		}

		FCharacterSaveData Data;
		Data.Attributes = CharacterDataMap[Id].Attributes;
		TempOwner->SetCharacterData(Data);

		TempOwner->AbilitySystemComponent->ApplyGameplayEffectToSelf(Effect, Level, TempOwner->AbilitySystemComponent->MakeEffectContext());

		// Update character data in subsystem
		for (UAttributeSet* Set : TempOwner->AbilitySystemComponent->GetSpawnedAttributes())
		{
			if (URPGAttributeSet* RPGSet = Cast<URPGAttributeSet>(Set))
			{
				CharacterDataMap[Id].Attributes = TempOwner->GetCharacterData().Attributes;
				RPGSet->SaveAttributesTo(CharacterDataMap[Id]);

				CharacterDataMap[Id].bIsSaveData = true; // Mark as save data
			}
		}
	}

	if (TempOwner)
	{
		TempOwner->Destroy();
	}
}

void UCharacterSubsystem::AddInstanceCharacter(ABaseCharacter* Character)
{
	if (InstanceCharacters.Contains(Character->GetInstanceId()))
	{
		return;
	}

	InstanceCharacters.Add(Character->GetInstanceId(), Character);
}

void UCharacterSubsystem::SetCharacterAvailability(const FRPGId& Id, const ECharacterAvailabilityStatus Status)
{
	if (CharacterDataMap.Contains(Id))
	{
		CharacterDataMap[Id].AvailabilityStatus = Status;
	}
}

bool UCharacterSubsystem::IsAvailable(const FRPGId& Id) const
{
	if (CharacterDataMap.Contains(Id))
	{
		return CharacterDataMap[Id].AvailabilityStatus == ECharacterAvailabilityStatus::Available;
	}

	return false;
}

ABaseCharacter* UCharacterSubsystem::SpawnCharacter(const FRPGId& Id, const TSubclassOf<ABaseCharacter> CharacterClass, const FVector Location, const FRotator Rotation, const bool bAsync)
{
	if (!Id.IsValid())
	{
		UE_LOG(LogCharacterSubsystem, Warning, TEXT("Spawn character with invalid Character Id!"));
		return nullptr;
	}

	if (bAsync)
	{
		FActorSpawnParameters Params;
		Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
		Params.OverrideLevel = GetWorld()->PersistentLevel;

		// Spawn the character actor immediately, but without data
		ABaseCharacter* NewCharacter = GetWorld()->SpawnActor<ABaseCharacter>(CharacterClass, Location, Rotation, Params);
		if (!IsValid(NewCharacter))
		{
			UE_LOG(LogCharacterSubsystem, Warning, TEXT("Failed to spawn async character for Id: %s"), *Id.ToString());
			return nullptr;
		}

		const FGuid CharacterGuid = NewCharacter->GetInstanceId();
		if (!InstanceCharacters.Contains(CharacterGuid))
		{
			UE_LOG(LogTemp, Display, TEXT("Spawning async character with Guid: %s"), *CharacterGuid.ToString());
			AddInstanceCharacter(NewCharacter);
		}

		BeginPartyMemberInitializationTracking(NewCharacter, CharacterGuid);

		// Apply data when asset is loaded
		TWeakObjectPtr<UCharacterSubsystem> WeakThis(this);
		URPGAssetLibrary::GetAssetByRPGIdAsync(Id, { "Character", "UI" }, [WeakThis, CharacterGuid](URPGPrimaryAsset* Asset)
			{
				if (UCharacterSubsystem* StrongThis = WeakThis.Get())
				{
					StrongThis->OnCharacterToSpawnLoaded(Asset, CharacterGuid);
				}
			});

		return NewCharacter;
	}
	else
	{
		URPGPrimaryAsset* Asset = URPGAssetLibrary::GetAssetByRPGId(Id);
		return SpawnCharacterByAsset(Cast<UCharacterAsset>(Asset), CharacterClass, Location, Rotation);
	}
}

ABaseCharacter* UCharacterSubsystem::SpawnCharacterByAsset(UCharacterAsset* Asset, const TSubclassOf<ABaseCharacter> CharacterClass, const FVector Location, const FRotator Rotation)
{
	if (!Asset)
	{
		UE_LOG(LogCharacterSubsystem, Warning, TEXT(__FUNCTION__ "Invalid Character Asset!"));
		return nullptr;
	}

	TSubclassOf<ABaseCharacter> SpawnClass = CharacterClass;
	if (!SpawnClass)
	{
		SpawnClass = ABaseCharacter::StaticClass();
	}

	FActorSpawnParameters Params;
	Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
	Params.OverrideLevel = GetWorld()->PersistentLevel;

	ABaseCharacter* NewCharacter = GetWorld()->SpawnActor<ABaseCharacter>(SpawnClass, Location, Rotation, Params);
	if (!IsValid(NewCharacter))
	{
		UE_LOG(LogCharacterSubsystem, Warning, TEXT("Failed to spawn character for asset: %s"), *GetNameSafe(Asset));
		return nullptr;
	}

	AddInstanceCharacter(NewCharacter);
	BeginPartyMemberInitializationTracking(NewCharacter, NewCharacter->GetInstanceId());

	if (FCharacterSaveData* SavedData = CharacterDataMap.Find(Asset->GetId()))
	{
		NewCharacter->InitCharacterData(Asset, *SavedData);
	}
	else
	{
		NewCharacter->InitCharacterDataDefault(Asset);
	}

	return NewCharacter;
}

void UCharacterSubsystem::DespawnCharacterInstance(const FGuid& Guid)
{
	if (!Guid.IsValid())
	{
		return;
	}

	if (ABaseCharacter* Character = InstanceCharacters.FindRef(Guid))
	{
		SaveCharacterDataToMap(Character);
		Character->Destroy();
	}

	InstanceCharacters.Remove(Guid);
}

void UCharacterSubsystem::DespawnCharacter(const FGuid& Guid)
{
	if (!Guid.IsValid())
	{
		return;
	}

	DespawnCharacterInstance(Guid);

	const int32 PartyIndex = PartyMemberGuids.IndexOfByKey(Guid);
	if (PartyIndex != INDEX_NONE)
	{
		PartyMemberGuids.RemoveAt(PartyIndex);
		if (PartyMemberIds.IsValidIndex(PartyIndex))
		{
			PartyMemberIds.RemoveAt(PartyIndex);
		}

		PlayerPartyIndex = PartyMemberIds.IsEmpty()
			? INDEX_NONE
			: FMath::Clamp(PlayerPartyIndex, 0, PartyMemberIds.Num() - 1);
	}
}

void UCharacterSubsystem::ClearPartyInitializationTracking()
{
	for (const TPair<FGuid, FDelegateHandle>& Pair : PartyInitDelegateHandles)
	{
		if (ABaseCharacter* Character = InstanceCharacters.FindRef(Pair.Key))
		{
			Character->OnCharacterDataInitialized.Remove(Pair.Value);
		}
	}

	PartyInitDelegateHandles.Empty();
	PendingPartyInitGuids.Empty();
}


void UCharacterSubsystem::ResetRuntimeCharactersForLoad()
{
	// Invalidate all delayed asset/preload callbacks before destroying their actors.
	++LoadRequestSerial;

	ClearPartyInitializationTracking();
	bIsSpawningPartyMembers = false;
	bPartyTeleportDone = false;

	if (APlayerController* PlayerController = UGameplayStatics::GetPlayerController(GetWorld(), 0))
	{
		PlayerController->UnPossess();
	}

	for (const TPair<FGuid, TObjectPtr<ABaseCharacter>>& Pair : InstanceCharacters)
	{
		if (IsValid(Pair.Value))
		{
			// Do not call DespawnCharacterInstance here: that function writes the
			// old runtime state back into CharacterDataMap and would overwrite the save.
			Pair.Value->Destroy();
		}
	}

	InstanceCharacters.Empty();
	PartyMemberGuids.Empty();
}

void UCharacterSubsystem::BeginPartyMemberInitializationTracking(ABaseCharacter* Character, const FGuid& Guid)
{
	if (!bIsSpawningPartyMembers || !IsValid(Character) || !Guid.IsValid())
	{
		return;
	}

	PendingPartyInitGuids.Add(Guid);
	if (PartyInitDelegateHandles.Contains(Guid))
	{
		return;
	}

	TWeakObjectPtr<UCharacterSubsystem> WeakThis(this);
	const FDelegateHandle Handle = Character->OnCharacterDataInitialized.AddLambda(
		[WeakThis, Guid](ABaseCharacter*)
		{
			if (UCharacterSubsystem* StrongThis = WeakThis.Get())
			{
				StrongThis->CompletePartyMemberInitialization(Guid);
			}
		});

	PartyInitDelegateHandles.Add(Guid, Handle);
}

void UCharacterSubsystem::CompletePartyMemberInitialization(const FGuid& Guid)
{
	if (!PendingPartyInitGuids.Remove(Guid))
	{
		return;
	}

	if (FDelegateHandle* Handle = PartyInitDelegateHandles.Find(Guid))
	{
		if (ABaseCharacter* Character = InstanceCharacters.FindRef(Guid))
		{
			Character->OnCharacterDataInitialized.Remove(*Handle);
		}
		PartyInitDelegateHandles.Remove(Guid);
	}

	UE_LOG(LogCharacterSubsystem, Verbose, TEXT("Party member initialized. Guid=%s Remaining=%d"), *Guid.ToString(), PendingPartyInitGuids.Num());
	TryBroadcastPartyReady();
}

void UCharacterSubsystem::FailPartyMemberInitialization(const FGuid& Guid, const TCHAR* Reason)
{
	if (PendingPartyInitGuids.Contains(Guid))
	{
		UE_LOG(LogCharacterSubsystem, Error, TEXT("Party member initialization failed. Guid=%s Reason=%s"), *Guid.ToString(), Reason);
		CompletePartyMemberInitialization(Guid);
	}
}

void UCharacterSubsystem::OnCharacterToSpawnLoaded(URPGPrimaryAsset* Asset, const FGuid InGuid)
{
	if (!Asset)
	{
		FailPartyMemberInitialization(InGuid, TEXT("Character asset could not be loaded."));
		return;
	}

	if (!InGuid.IsValid())
	{
		UE_LOG(LogCharacterSubsystem, Warning, TEXT("Invalid Guid provided to OnCharacterToSpawnLoaded!"));
		return;
	}

	ABaseCharacter* Instance = InstanceCharacters.FindRef(InGuid);
	if (!IsValid(Instance))
	{
		FailPartyMemberInitialization(InGuid, TEXT("Character instance no longer exists."));
		return;
	}

	const UCharacterAsset* CharacterAsset = Cast<UCharacterAsset>(Asset);
	if (!CharacterAsset)
	{
		FailPartyMemberInitialization(InGuid, TEXT("Loaded asset is not a Character Asset."));
		return;
	}

	// Bind before initialization. Some initialization paths can finish immediately.
	BeginPartyMemberInitializationTracking(Instance, InGuid);

	SaveCharacterDataToMap(Instance);

	if (FCharacterSaveData* SavedData = CharacterDataMap.Find(Asset->GetId()))
	{
		Instance->InitCharacterData(CharacterAsset, *SavedData);
	}
	else
	{
		Instance->InitCharacterDataDefault(CharacterAsset);
	}
}

void UCharacterSubsystem::TryBroadcastPartyReady()
{
	if (!bIsSpawningPartyMembers || !bPartyTeleportDone || !PendingPartyInitGuids.IsEmpty())
	{
		return;
	}

	bIsSpawningPartyMembers = false;
	OnPartyReady.Broadcast();
	OnPartyConstructed.Broadcast();
}

TArray<ABaseCharacter*> UCharacterSubsystem::GetPartyMembers() const
{
	TArray<ABaseCharacter*> Result;
	for (const FGuid& Guid : PartyMemberGuids)
	{
		if (Guid.IsValid())
		{
			if (ABaseCharacter* Member = Cast<ABaseCharacter>(InstanceCharacters.FindRef(Guid)))
			{
				Result.Add(Member);
			}
		}
	}

	return Result;
}

ABaseCharacter* UCharacterSubsystem::GetPlayerCharacter() const
{
	if (!PartyMemberGuids.IsValidIndex(PlayerPartyIndex))
	{
		return nullptr;
	}

	return InstanceCharacters.FindRef(PartyMemberGuids[PlayerPartyIndex]);
}

TArray<ABaseCharacter*> UCharacterSubsystem::GetPartyMemberInstances() const
{
	TArray<ABaseCharacter*> PartyMemberInstances;
	PartyMemberInstances.Reserve(PartyMemberGuids.Num());

	for (const FGuid& Guid : PartyMemberGuids)
	{
		if (ABaseCharacter* Instance = InstanceCharacters.FindRef(Guid))
		{
			PartyMemberInstances.Add(Instance);
		}
	}

	return PartyMemberInstances;
}

ABaseCharacter* UCharacterSubsystem::GetPartyMemberInstanceById(const FRPGId& Id) const
{
	const int32 Index = PartyMemberIds.IndexOfByKey(Id);
	if (!PartyMemberGuids.IsValidIndex(Index))
	{
		return nullptr;
	}

	return InstanceCharacters.FindRef(PartyMemberGuids[Index]);
}

void UCharacterSubsystem::SpawnPartyMembers(const FVector Location, const FRotator Rotation, bool bAsync, ESpawnPartyMode SpawnPartyMode)
{
	SpawnNewPartyMembers(PartyMemberIds, Location, Rotation, bAsync, SpawnPartyMode);
}

void UCharacterSubsystem::SpawnPartyMembers(const FTransform Transform, bool bAsync, ESpawnPartyMode SpawnPartyMode)
{
	SpawnNewPartyMembers(PartyMemberIds, Transform.GetLocation(), Transform.Rotator(), bAsync, SpawnPartyMode);
}

void UCharacterSubsystem::SpawnNewPartyMembers(TArray<FRPGId> NewParty, const FVector Location, const FRotator Rotation, bool bAsync, ESpawnPartyMode SpawnPartyMode)
{
	if (bIsSpawningPartyMembers)
	{
		UE_LOG(LogCharacterSubsystem, Warning, TEXT("Cannot spawn party members while another spawn is in progress!"));
		return;
	}

	if (!PlayableCharacterClass)
	{
		UE_LOG(LogCharacterSubsystem, Warning, TEXT("PlayableCharacterClass is nullptr!"));
		return;
	}

	NewParty.RemoveAll([](const FRPGId& MemberId)
		{
			return !MemberId.IsValid();
		});

	if (NewParty.Num() > MaxPartyMembers)
	{
		NewParty.SetNum(MaxPartyMembers);
		UE_LOG(LogCharacterSubsystem, Warning, TEXT("NewParty exceeds MaxPartyMembers. Truncated."));
	}

	if (NewParty.IsEmpty())
	{
		UE_LOG(LogCharacterSubsystem, Warning, TEXT("NewParty is empty!"));
		return;
	}

	bIsSpawningPartyMembers = true;
	bPartyTeleportDone = false;
	ClearPartyInitializationTracking();

	const TArray<FRPGId> OldPartyIds = PartyMemberIds;
	const TArray<FGuid> OldPartyGuids = PartyMemberGuids;

	FRPGId PreviouslyControlledId;
	if (SpawnPartyMode == ESpawnPartyMode::KeepControlSameCharacter && OldPartyIds.IsValidIndex(PlayerPartyIndex))
	{
		PreviouslyControlledId = OldPartyIds[PlayerPartyIndex];
	}

	TArray<FGuid> NewPartyGuids;
	NewPartyGuids.SetNum(NewParty.Num());
	TSet<FGuid> ReusedGuids;

	// Reuse only matching character instances. New slots always receive a new actor,
	// which keeps PartyMemberIds[i] and PartyMemberGuids[i] permanently aligned.
	for (int32 NewIndex = 0; NewIndex < NewParty.Num(); ++NewIndex)
	{
		for (int32 OldIndex = 0; OldIndex < OldPartyIds.Num(); ++OldIndex)
		{
			if (OldPartyIds[OldIndex] != NewParty[NewIndex] || !OldPartyGuids.IsValidIndex(OldIndex))
			{
				continue;
			}

			const FGuid CandidateGuid = OldPartyGuids[OldIndex];
			if (!CandidateGuid.IsValid() || ReusedGuids.Contains(CandidateGuid))
			{
				continue;
			}

			if (ABaseCharacter* Candidate = InstanceCharacters.FindRef(CandidateGuid))
			{
				if (Candidate->GetId() == NewParty[NewIndex])
				{
					NewPartyGuids[NewIndex] = CandidateGuid;
					ReusedGuids.Add(CandidateGuid);
					break;
				}
			}
		}
	}

	PartyMemberIds = NewParty;
	PartyMemberGuids = NewPartyGuids;

	for (int32 Index = 0; Index < NewParty.Num(); ++Index)
	{
		if (PartyMemberGuids[Index].IsValid())
		{
			continue;
		}

		const FRPGId& SpawnId = NewParty[Index];
		ABaseCharacter* NewCharacter = SpawnCharacter(SpawnId, PlayableCharacterClass, Location, Rotation, bAsync);
		if (!IsValid(NewCharacter))
		{
			UE_LOG(LogCharacterSubsystem, Error, TEXT("Failed to spawn party member for asset: %s"), *SpawnId.ToString());
			continue;
		}

		const FGuid NewGuid = NewCharacter->GetInstanceId();
		PartyMemberGuids[Index] = NewGuid;

	}

	for (const FGuid& OldGuid : OldPartyGuids)
	{
		if (OldGuid.IsValid() && !ReusedGuids.Contains(OldGuid))
		{
			DespawnCharacterInstance(OldGuid);
		}
	}

	if (SpawnPartyMode == ESpawnPartyMode::KeepControlSameCharacter)
	{
		const int32 NewPlayerIndex = NewParty.IndexOfByKey(PreviouslyControlledId);
		PlayerPartyIndex = NewPlayerIndex != INDEX_NONE ? NewPlayerIndex : 0;
	}
	else
	{
		PlayerPartyIndex = FMath::Clamp(PlayerPartyIndex, 0, NewParty.Num() - 1);
	}

	TeleportPartyMembers(Location, Rotation);
	bPartyTeleportDone = true;
	TryBroadcastPartyReady();
}

void UCharacterSubsystem::TeleportPartyMembers(const FVector Location, const FRotator Rotation)
{
	for (int32 i = 0; i < PartyMemberGuids.Num(); i++)
	{
		const FGuid& Guid = PartyMemberGuids[i];
		if (!Guid.IsValid() || !InstanceCharacters.Contains(Guid))
		{
			continue;
		}

		FVector SpawnLocation = Location;
		FRotator SpawnRotation = Rotation;

		if (i != PlayerPartyIndex)
		{
			SpawnLocation.X += FMath::RandRange(-SpawnLocationOffset, SpawnLocationOffset);
			SpawnLocation.Y += FMath::RandRange(-SpawnLocationOffset, SpawnLocationOffset);
			SpawnRotation.Yaw += FMath::RandRange(-SpawnRotationOffset, SpawnRotationOffset);
		}

		InstanceCharacters[Guid]->SetActorLocationAndRotation(SpawnLocation, SpawnRotation);

		// TODO: Reset character state (e.g., stop animations, reset physics, etc.)
	}
}

void UCharacterSubsystem::AddPartyMember(const FRPGId& Id, const int32 Index)
{
	EPartyOperationResult Result;
	AddPartyMember(Result, Id, Index);
}

void UCharacterSubsystem::RemovePartyMember(const FRPGId& Id)
{
	EPartyOperationResult Result;
	RemovePartyMember(Result, Id);
}

void UCharacterSubsystem::RemovePartyMemberByIndex(const int32 Index)
{
	EPartyOperationResult Result;
	RemovePartyMemberByIndex(Result, Index);
}

void UCharacterSubsystem::AddPartyMember(OUT EPartyOperationResult& Result, const FRPGId& Id, const int32 Index)
{
	const auto* Data = CharacterDataMap.Find(Id);
	if (!Data)
	{
		Result = EPartyOperationResult::CharacterNotFound;
		return;
	}

	if (!IsAvailable(Id))
	{
		Result = EPartyOperationResult::CharacterUnavailable;
		return;
	}

	if (IsPartyMember(Id))
	{
		Result = EPartyOperationResult::AlreadyInParty;
		return;
	}

	if (PartyMemberIds.IsValidIndex(Index))
	{
		PartyMemberIds[Index] = Id;
	}
	else if (Index != INDEX_NONE)
	{
		Result = EPartyOperationResult::InvalidOperation;
		return;
	}

	for (FRPGId& MemberId : PartyMemberIds)
	{
		if (!MemberId.IsValid())
		{
			MemberId = Id;

			Result = EPartyOperationResult::Success;
			return;
		}
	}

	if (PartyMemberIds.Num() < MaxPartyMembers)
	{
		PartyMemberIds.Add(Id);

		Result = EPartyOperationResult::Success;
	}
	else
	{
		Result = EPartyOperationResult::PartyFull;
	}
}

void UCharacterSubsystem::RemovePartyMember(OUT EPartyOperationResult& Result, const FRPGId& Id)
{
	const auto* Data = CharacterDataMap.Find(Id);
	if (!Data)
	{
		Result = EPartyOperationResult::CharacterNotFound;
		return;
	}

	int32 FoundIndex = PartyMemberIds.IndexOfByKey(Id);
	if (FoundIndex != INDEX_NONE)
	{
		PartyMemberIds[FoundIndex] = FRPGId();

		Result = EPartyOperationResult::Success;
	}
	else
	{
		Result = EPartyOperationResult::NotInParty;
	}
}

void UCharacterSubsystem::RemovePartyMemberByIndex(OUT EPartyOperationResult& Result, const int32 Index)
{
	if (PartyMemberIds.IsValidIndex(Index))
	{
		PartyMemberIds[Index] = FRPGId();

		Result = EPartyOperationResult::Success;
		return;
	}

	Result = EPartyOperationResult::InvalidOperation;
}

bool UCharacterSubsystem::IsPartyMember(const FRPGId& Id) const
{
	return PartyMemberIds.Contains(Id);
}

int32 UCharacterSubsystem::GetPartyIndexById(const FRPGId& Id) const
{
	return PartyMemberIds.Find(Id);
}

bool UCharacterSubsystem::CanJoinParty(const FRPGId& Id) const
{
	return IsAvailable(Id);
}

bool UCharacterSubsystem::IsPartyEmpty() const
{
	return PartyMemberIds.IsEmpty() || !PartyMemberIds.FindByPredicate([](FRPGId Item)
		{
			return Item.IsValid();
		});
}

void UCharacterSubsystem::SwitchToCharacter(ESwitchCharacterPolicy SwitchPolicy, float DurationOverridden, bool bCanSwitchToDead)
{
	auto GetNextIndex = [](ESwitchCharacterPolicy InSwitchPolicy)
	{
		return InSwitchPolicy == ESwitchCharacterPolicy::ToNext ? 1 : -1;
	};

	int32 Index = PlayerPartyIndex + GetNextIndex(SwitchPolicy);

	while (Index != PlayerPartyIndex)
	{
		if (Index >= PartyMemberGuids.Num())
		{
			Index = 0;
		}
		else if (Index < 0)
		{
			Index = PartyMemberGuids.Num() - 1;
		}

		ABaseCharacter* Current = InstanceCharacters.FindRef(PartyMemberGuids[Index]);
		check(Current);
		
		if (bCanSwitchToDead || !(Current->CombatComponent && Current->CombatComponent->IsCharacterDead()))
		{
			SwitchPlayerCharacterByIndex(Index, DurationOverridden);
			return;
		}

		Index += GetNextIndex(SwitchPolicy);
	}
}

void UCharacterSubsystem::SwitchPlayerCharacterByIndex(const int32 Index, const float DurationOverridden)
{
	if (!PartyMemberGuids.IsValidIndex(Index))
	{
		return;
	}

	if (APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0))
	{
		ABaseCharacter* OldPlayerCharacter = GetPlayerCharacter();
		ABaseCharacter* NewPlayerCharacter = InstanceCharacters.FindRef(PartyMemberGuids[Index]);

		if (OldPlayerCharacter && NewPlayerCharacter)
		{
			if (OldPlayerCharacter == NewPlayerCharacter)
			{
				return;
			}
			
			// We do not want character to move when switching
			if (UCharacterControlComponent* ControlComponent = PC->FindComponentByClass<UCharacterControlComponent>())
			{
				ControlComponent->DisableAllInputs();
			}

			if (ARPGPlayerCameraManager* CamMgr = Cast<ARPGPlayerCameraManager>(PC->PlayerCameraManager))
			{
				CamMgr->ActorCameraViewTransition(
					NewPlayerCharacter,
					DurationOverridden >= 0.0f ? DurationOverridden : SwitchCharacterDuration,
					nullptr,
					[this, Index, NewPlayerCharacter, OldPlayerCharacter](const FVector& Position, const FRotator& Rotation) {
						PlayerPartyIndex = Index;
						UpdatePossessedCharacter(OldPlayerCharacter, NewPlayerCharacter, Position, Rotation);
					}
				);
			}
		}
	}
}

void UCharacterSubsystem::SwitchPlayerCharacterById(const FRPGId& Id, const float DurationOverridden)
{
	SwitchPlayerCharacterByIndex(PartyMemberIds.IndexOfByKey(Id), DurationOverridden);
}

void UCharacterSubsystem::UpdatePossessedCharacter(ABaseCharacter* OldCharacter, ABaseCharacter* NewCharacter, const FVector& Position, const FRotator& Rotation)
{
	if (!NewCharacter)
	{
		return;
	}

	if (ARPGPlayerController* PC = Cast<ARPGPlayerController>(UGameplayStatics::GetPlayerController(GetWorld(), 0)))
	{
		// A camera transition can theoretically complete after another possession
		// path has already selected this pawn. Avoid a redundant direct Possess;
		// ARPGPlayerController::PossessCharacter also protects this invariant for
		// the party-ready path.
		if (PC->GetPawn() != NewCharacter)
		{
			PC->PossessCharacter(NewCharacter);
		}

		PC->SetControlRotation(Rotation);
	}
	else
	{
		UE_LOG(LogCharacterSubsystem, Warning, TEXT("PlayerController is not a RPGPlayerController!"));
	}
}

FName UCharacterSubsystem::GetSaveModuleType() const
{
	return FCharacterSaveModule::StaticStruct()->GetFName();
}

void UCharacterSubsystem::SaveDataTo(FInstancedStruct& SaveData)
{
	SaveData.Reset();

	FCharacterSaveModule CharacterSave;
	
	// Force save all party members' data to map before saving
	SavePartyMembersDataToMap();

	CharacterSave.CharacterData = CharacterDataMap;

	CharacterSave.PlayerPartyIndex = PlayerPartyIndex;
	CharacterSave.PartyMembers = PartyMemberIds;

	SaveData.InitializeAs<FCharacterSaveModule>(CharacterSave);
}

void UCharacterSubsystem::LoadDataFrom(const FInstancedStruct& SaveData)
{
	// GameInstanceSubsystem survives map changes and repeated loads. Clear the
	// previous runtime layer before accepting the new saved data.
	ResetRuntimeCharactersForLoad();
	const uint32 ThisLoadRequest = LoadRequestSerial;
	TWeakObjectPtr<UCharacterSubsystem> WeakThis(this);

	if (const FCharacterSaveModule* CharacterSave = SaveData.GetPtr<FCharacterSaveModule>())
	{
		CharacterDataMap = CharacterSave->CharacterData;
		PlayerPartyIndex = CharacterSave->PlayerPartyIndex;
		PartyMemberIds = CharacterSave->PartyMembers;

		URPGAssetLibrary::GetAssetArrayByRPGIdsAsync(PartyMemberIds, { "Character", "UI" },
			[WeakThis, ThisLoadRequest](TArray<URPGPrimaryAsset*>)
			{
				if (UCharacterSubsystem* StrongThis = WeakThis.Get(); StrongThis && StrongThis->LoadRequestSerial == ThisLoadRequest)
				{
					StrongThis->OnLoadComplete().Broadcast();
				}
			});
		return;
	}

	const URPGSettings* Settings = URPGSettings::GetRPGSettings();
	if (!Settings)
	{
		OnLoadComplete().Broadcast();
		return;
	}

	PartyMemberIds = Settings->DefaultPartyMembers;
	PlayerPartyIndex = Settings->DefaultPlayerIndex;
	const TArray<FRPGId> DefaultParty = Settings->DefaultPartyMembers;

	URPGAssetLibrary::GetAssetArrayByRPGIdsAsync(Settings->PlayableCharacters, {},
		[WeakThis, ThisLoadRequest, DefaultParty](TArray<URPGPrimaryAsset*> Result)
		{
			UCharacterSubsystem* StrongThis = WeakThis.Get();
			if (!StrongThis || StrongThis->LoadRequestSerial != ThisLoadRequest)
			{
				return;
			}

			for (URPGPrimaryAsset* Asset : Result)
			{
				if (UCharacterAsset* CharacterAsset = Cast<UCharacterAsset>(Asset))
				{
					StrongThis->CharacterDataMap.Add(Asset->GetId(), CharacterAsset->GetDefaultData());
				}
			}

			URPGAssetLibrary::GetAssetArrayByRPGIdsAsync(DefaultParty, { "Character", "UI" },
				[WeakThis, ThisLoadRequest](TArray<URPGPrimaryAsset*>)
				{
					if (UCharacterSubsystem* CurrentThis = WeakThis.Get(); CurrentThis && CurrentThis->LoadRequestSerial == ThisLoadRequest)
					{
						CurrentThis->OnLoadComplete().Broadcast();
					}
				});
		});
}

FSimpleMulticastDelegate& UCharacterSubsystem::OnLoadComplete()
{
	return LoadCompleteDelegate;
}
