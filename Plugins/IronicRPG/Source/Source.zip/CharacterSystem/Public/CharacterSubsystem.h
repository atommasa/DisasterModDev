// Copyright Ironic Studio. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Subsystems/RPGGameInstanceSubsystem.h"
#include "Characters/BaseCharacter.h"
#include "Controllers/RPGPlayerController.h"
#include "Characters/CharacterAsset.h"
#include "SaveGame/Saveable.h"
#include "Characters/CharacterDataTypes.h"
#include "DataTypes/RPGId.h"
#include "CharacterSubsystem.generated.h"

DECLARE_LOG_CATEGORY_EXTERN(LogCharacterSubsystem, Log, All);

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnPartyReady);
DECLARE_MULTICAST_DELEGATE(FOnPartyConstructed);

class URPGPrimaryAsset;
class UCharacterAsset;

UENUM(BlueprintType)
enum class EPartyOperationResult : uint8
{
	Success UMETA(DisplayName = "Success"),
	InvalidOperation UMETA(DisplayName = "Invalid Operation"),
	CharacterNotFound UMETA(DisplayName = "Character Not Found"),
	CharacterUnavailable UMETA(DisplayName = "Character Unavailable"),
	PartyFull UMETA(DisplayName = "Party Full"),
	AlreadyInParty UMETA(DisplayName = "Already In Party"),
	NotInParty UMETA(DisplayName = "Not In Party")
};

UENUM(BlueprintType)
enum class ESwitchCharacterPolicy : uint8
{
	ToNext,
	ToPrevious,
};

UENUM(BlueprintType)
enum class ESpawnPartyMode : uint8
{
	KeepControlSameCharacter UMETA(DisplayName = "Keep Control Same Character"),
	ByPlayerPartyIndex UMETA(DisplayName = "By Player Party Index")
};

/**
 * Character Subsystem to manage character data and instances.
 */
UCLASS(Blueprintable)
class CHARACTERSYSTEM_API UCharacterSubsystem : public URPGGameInstanceSubsystem, public ISaveable
{
	GENERATED_BODY()

protected: // Subsystem Interface
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;
	
// ============
//  Data Layer
// ============

public:
	// Map of character data, keyed by character Id, but only stores CHARACTER DATA YOU WANT TO SAVE
	// And it is not "Authority Data", so we recommend that you only use it for loading and saving
	// The actual runtime data is owned by the character itself
	// Or you should call SavePartyMembersDataToMap() to sync the data with all character assets in the game
	UPROPERTY(BlueprintReadWrite, Category = "Character")
	TMap<FRPGId, FCharacterSaveData> CharacterDataMap;

	// Save a single character's data to CharacterDataMap
	UFUNCTION(BlueprintCallable)
	virtual void SaveCharacterDataToMap(ABaseCharacter* Instance);

	// Save all party members' data to CharacterDataMap
	UFUNCTION(BlueprintCallable)
	virtual void SavePartyMembersDataToMap();

	// Modify the character data of multiple characters by applying a gameplay effect
	// Only modifies the data in CharacterDataMap, does not affect the actual character instances
	// If you want to modify the actual character instances, you should apply the effect to them directly
	UFUNCTION(BlueprintCallable)
	virtual void ModifyCharactersData(const TArray<FRPGId>& Ids, UGameplayEffect* Effect, const float Level = 1.0f);

// =================
//  Instance Layer
// =================

public:
	// Instances of characters currently in the game
	UPROPERTY(BlueprintReadOnly, Category = "Character")
	TMap<FGuid, TObjectPtr<ABaseCharacter>> InstanceCharacters;

	UFUNCTION(BlueprintCallable)
	void AddInstanceCharacter(ABaseCharacter* Character);
	
	// Set the availability status of a character
	UFUNCTION(BlueprintCallable)
	void SetCharacterAvailability(const FRPGId& Id, const ECharacterAvailabilityStatus Status);

	UFUNCTION(BlueprintCallable)
	bool IsAvailable(const FRPGId& Id) const;

	/**
	 * Use a RPGId to spawn a character
	 * 
	 * @param Id The RPGId of a character that you want to spawn.
	 * @param CharacterClass The character class of the character instance. If it is nullptr, use ABaseCharacter as default.
	 * @param Location Location to spawn.
	 * @param Rotation Rotation to spawn.
	 * @param bAsync Whether to load the character asset asynchronously. If true, the character will spawn synchronously, but data will be loaded asynchronously.
	 */
	UFUNCTION(BlueprintCallable)
	ABaseCharacter* SpawnCharacter(
		const FRPGId& Id,
		const TSubclassOf<ABaseCharacter> CharacterClass = nullptr,
		const FVector Location = FVector::ZeroVector,
		const FRotator Rotation = FRotator::ZeroRotator,
		const bool bAsync = true
	);

	/**
	 * Use a character asset to spawn a character
	 *
	 * @param Asset The asset of a character that you want to spawn.
	 * @param CharacterClass The character class of the character instance. If it is nullptr, use ABaseCharacter as default.
	 * @param Location Location to spawn.
	 * @param Rotation Rotation to spawn.
	 */
	UFUNCTION(BlueprintCallable)
	ABaseCharacter* SpawnCharacterByAsset(
		UCharacterAsset* Asset,
		const TSubclassOf<ABaseCharacter> CharacterClass = nullptr,
		const FVector Location = FVector::ZeroVector,
		const FRotator Rotation = FRotator::ZeroRotator
	);

	UFUNCTION(BlueprintCallable)
	void DespawnCharacter(const FGuid& Guid);

	// On party ready, broadcast when all party members are spawned and ready, and the player character is possessed
	UPROPERTY(BlueprintAssignable)
	FOnPartyReady OnPartyReady;

	// On party constructed, for C++ use, broadcast when all party members are spawned
	FOnPartyConstructed OnPartyConstructed;

private:
	void OnCharacterToSpawnLoaded(URPGPrimaryAsset* Asset, const FGuid InGuid);
	void DespawnCharacterInstance(const FGuid& Guid);
	void BeginPartyMemberInitializationTracking(ABaseCharacter* Character, const FGuid& Guid);
	void CompletePartyMemberInitialization(const FGuid& Guid);
	void FailPartyMemberInitialization(const FGuid& Guid, const TCHAR* Reason);
	void ClearPartyInitializationTracking();
	// Removes only runtime actors. It intentionally does not save them back into
	// CharacterDataMap because LoadDataFrom has already replaced that map with save data.
	void ResetRuntimeCharactersForLoad();

	bool bIsSpawningPartyMembers = false;

	// Track the exact party instances that are still waiting for their character data.
	// A Guid set is safer than a counter because callbacks can be delayed or duplicated.
	TSet<FGuid> PendingPartyInitGuids;
	TMap<FGuid, FDelegateHandle> PartyInitDelegateHandles;

	bool bPartyTeleportDone = false;

	// Reject delayed preload callbacks from an older LoadGame request.
	uint32 LoadRequestSerial = 0;

	void TryBroadcastPartyReady();

protected:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Character|Party")
	TSubclassOf<ABaseCharacter> PlayableCharacterClass = ABaseCharacter::StaticClass();

	// Offset distance between spawned party members.
	UPROPERTY(EditDefaultsOnly, Category = "Character|Party")
	float SpawnLocationOffset = 200.0f;

	// Offset angle between spawned party members.
	UPROPERTY(EditDefaultsOnly, Category = "Character|Party")
	float SpawnRotationOffset = 60.0f;

public: // Party Functions
	UPROPERTY(BlueprintReadOnly, Category = "Character|Party")
	int32 PlayerPartyIndex;

	UPROPERTY(BlueprintReadOnly, Category = "Character|Party")
	TArray<FRPGId> PartyMemberIds;

	UPROPERTY(BlueprintReadOnly, Category = "Character|Party")
	TArray<FGuid> PartyMemberGuids;

	UPROPERTY(BlueprintReadOnly, Category = "Character|Party")
	int32 MaxPartyMembers;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Character|Party", meta=(ClampMin = 0.0f))
	float SwitchCharacterDuration = 1.f;

	UFUNCTION(BlueprintPure, Category = "Character|Party")
	TArray<ABaseCharacter*> GetPartyMembers() const;

	UFUNCTION(BlueprintPure, Category = "Character|Party")
	ABaseCharacter* GetPlayerCharacter() const;

	UFUNCTION(BlueprintPure, Category = "Character|Party")
	TArray<ABaseCharacter*> GetPartyMemberInstances() const;

	UFUNCTION(BlueprintPure, Category = "Character|Party")
	ABaseCharacter* GetPartyMemberInstanceById(const FRPGId& Id) const;

	UFUNCTION(BlueprintCallable, Category = "Character|Party")
	void SpawnPartyMembers(const FVector Location, const FRotator Rotation, bool bAsync = true, ESpawnPartyMode SpawnPartyMode = ESpawnPartyMode::KeepControlSameCharacter);
	void SpawnPartyMembers(const FTransform Transform, bool bAsync = true, ESpawnPartyMode SpawnPartyMode = ESpawnPartyMode::KeepControlSameCharacter);

	UFUNCTION(BlueprintCallable, Category = "Character|Party")
	void SpawnNewPartyMembers(TArray<FRPGId> NewParty, const FVector Location, const FRotator Rotation, bool bAsync = true, ESpawnPartyMode SpawnPartyMode = ESpawnPartyMode::KeepControlSameCharacter);
	
	UFUNCTION(BlueprintCallable, Category = "Character|Party")
	void TeleportPartyMembers(const FVector Location, const FRotator Rotation);

	FORCEINLINE void AddPartyMember(const FRPGId& Id, const int32 Index = -1);
	
	FORCEINLINE void RemovePartyMember(const FRPGId& Id);

	FORCEINLINE void RemovePartyMemberByIndex(const int32 Index);

	UFUNCTION(BlueprintCallable, Category = "Character|Party", meta=(ExpandEnumAsExecs = Result, AdvancedDisplay = 3))
	FORCEINLINE void AddPartyMember(EPartyOperationResult& Result, const FRPGId& Id, const int32 Index = -1);

	UFUNCTION(BlueprintCallable, Category = "Character|Party", meta=(ExpandEnumAsExecs = Result, AdvancedDisplay = 3))
	FORCEINLINE void RemovePartyMember(EPartyOperationResult& Result, const FRPGId& Id);

	UFUNCTION(BlueprintCallable, Category = "Character|Party", meta=(ExpandEnumAsExecs = Result, AdvancedDisplay = 3))
	FORCEINLINE void RemovePartyMemberByIndex(EPartyOperationResult& Result, const int32 Index);

	UFUNCTION(BlueprintPure, Category = "Character|Party")
	bool IsPartyMember(const FRPGId& Id) const;

	UFUNCTION(BlueprintPure, Category = "Character|Party")
	int32 GetPartyIndexById(const FRPGId& Id) const;

	UFUNCTION(BlueprintPure, Category = "Character|Party")
	bool CanJoinParty(const FRPGId& Id) const;

	UFUNCTION(BlueprintPure, Category = "Character|Party")
	bool IsPartyEmpty() const;

	UFUNCTION(BlueprintPure, Category = "Character|Party")
	int32 GetMaxPartyMembers() const { return MaxPartyMembers; }

	UFUNCTION(BlueprintCallable, Category = "Character|Party")
	void SwitchToCharacter(ESwitchCharacterPolicy SwitchPolicy, float DurationOverridden = -1.0f, bool bCanSwitchToDead = false);

	UFUNCTION(BlueprintCallable, Category = "Character|Party")
	void SwitchPlayerCharacterByIndex(const int32 Index, const float DurationOverridden = -1.0f);

	UFUNCTION(BlueprintCallable, Category = "Character|Party")
	void SwitchPlayerCharacterById(const FRPGId& Id, const float DurationOverridden = -1.0f);

private:
	void UpdatePossessedCharacter(ABaseCharacter* OldCharacter, ABaseCharacter* NewCharacter, const FVector& Position, const FRotator& Rotation);

public: // ISaveable
	virtual FName GetSaveModuleType() const override;
	virtual void SaveDataTo(FInstancedStruct& SaveData) override;
	virtual void LoadDataFrom(const FInstancedStruct& SaveData) override;

	virtual FSimpleMulticastDelegate& OnLoadComplete() override;
	FSimpleMulticastDelegate LoadCompleteDelegate;

};
