// Copyright Ironic Studio. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Subsystems/RPGGameInstanceSubsystem.h"

#include "Levels/GameZoneContext.h"
#include "Levels/MapMarkerData.h"

#include "SaveGame/Saveable.h"

#include "GameZoneSubsystem.generated.h"

class UMapMarkerComponent;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnMapMarkerChanged, const FGuid&, MarkerId);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnMapMarkerUnregistered, const FGuid&, MarkerId);

/**
 * 
 */
UCLASS(Blueprintable)
class GAMEZONESYSTEM_API UGameZoneSubsystem : public URPGGameInstanceSubsystem, public ISaveable
{
	GENERATED_BODY()
	
protected:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

public:
	// Enters a game zone with the specified context.
	void EnterGameZone(const FGameZoneContext& NewGameZoneContext, TDelegate<void()> DelegateToCall = TDelegate<void()>());

	void LoadZone(const FGameZoneContext& LoadContext, TDelegate<void()> DelegateToCall = TDelegate<void()>());
	void LoadSubZone(const FGameZoneContext& LoadContext, TDelegate<void()> DelegateToCall = TDelegate<void()>());

	void CreateStreamInstance(UWorld* World, const FString& LongPackageName, const FVector& Location = FVector::ZeroVector, const FRotator& Rotation = FRotator::ZeroRotator);

	UFUNCTION(BlueprintCallable, Category = "RPG|GameZone")
	FGameZoneContext GetCurrentContext() const { return CurrentContext; }

	// Only used for loading the player start point when loading a game, it will find the player start point based on the current context and return its transform
	UFUNCTION(BlueprintCallable, Category = "RPG|GameZone")
	FTransform GetSaveGameTransform() const; // TODO: API �n���n��W�r�A�Ϊ̹��շs�W API

	UFUNCTION(BlueprintCallable, Category = "RPG|GameZone")
	class UGameZoneAsset* FindZoneAssetForCurrentMap() const;

public:
	UFUNCTION(BlueprintCallable, Category = "RPG|GameZone")
	void RegisterMapMarkerComponent(UMapMarkerComponent* MarkerComponent);

	UFUNCTION(BlueprintCallable, Category = "RPG|GameZone")
	void UnregisterMapMarkerComponent(UMapMarkerComponent* MarkerComponent);

	void RegisterBakedMarkersFromZone(const FRPGId& ZoneId);

public:
	UPROPERTY(BlueprintAssignable, Category = "RPG|GameZone")
	FOnMapMarkerChanged OnMapMarkerChanged;

	UPROPERTY(BlueprintAssignable, Category = "RPG|GameZone")
	FOnMapMarkerUnregistered OnMapMarkerUnregistered;

private:
	TMap<FGuid, FMapMarkerData> MapMarkerRegistry;

private:
	UFUNCTION()
	void WaitUntilLevelActorInitialized();

	ULevelStreaming* CurrentStreaming = nullptr;
	// LoadZone completes only after the streamed level is ready.
	TDelegate<void()> PendingZoneLoadCompleteDelegate;

	FGameZoneContext CurrentContext;

	FGameZoneContext PendingContext;

public: // ISaveable
	virtual FName GetSaveModuleType() const override;
	virtual void SaveDataTo(FInstancedStruct& SaveData) override;
	virtual void LoadDataFrom(const FInstancedStruct& SaveData) override;

	virtual FSimpleMulticastDelegate& OnLoadComplete() override;
	FSimpleMulticastDelegate LoadCompleteDelegate;
};
