// Copyright Ironic Studio. All Rights Reserved.


#include "Nodes/NarrativeBranchNode.h"
#include "Nodes/NarrativeBranchNodeInfo.h"
#include "NarrativeEditorUtils.h"
#include "K2Node_FunctionResult.h"

TSharedPtr<SGraphNode> UNarrativeBranchNode::CreateVisualWidget()
{
	return SNew(SNarrativeBranchNode, this);
}

void UNarrativeBranchNode::AllocateDefaultPins()
{
	SetNodeInfo(NewObject<UNarrativeBranchNodeInfo>(this));
	
	CreateNarrativePin(EEdGraphPinDirection::EGPD_Input, TEXT(""));
	CreateNarrativePin(EEdGraphPinDirection::EGPD_Output, TEXT("True"));
	CreateNarrativePin(EEdGraphPinDirection::EGPD_Output, TEXT("False"));
}

FName UNarrativeBranchNode::CreateCallableBindingName() const
{
	return FName(*FString::Printf(TEXT("IsConditionMet_%s"), *NodeGuid.ToString()));
}

FText UNarrativeBranchNode::CreateCallableBindingComment() const
{
	return FText::FromString(TEXT("Define your own condition logic in this function."));
}

void UNarrativeBranchNode::CreateCallableBindingParameterPins(UK2Node_EditablePinBase* InNode)
{
	if (InNode->IsA<UK2Node_FunctionResult>())
	{
		FNarrativeEditorUtils::CreateUserDefinedPinFor(
			InNode,
			TEXT("Result"),
			FEdGraphPinType(
				UEdGraphSchema_K2::PC_Boolean,
				NAME_None,
				nullptr,
				EPinContainerType::None,
				false,
				FEdGraphTerminalType()
			),
			EGPD_Input
		);
	}
}

TSharedRef<SWidget> SNarrativeBranchNode::CreateNarrativeNodeCenterContent()
{
	UNarrativeBranchNode* BranchNode = Cast<UNarrativeBranchNode>(GraphNode);
	if (!BranchNode)
	{
		return SNullWidget::NullWidget;
	}

	UNarrativeBranchNodeInfo* BranchNodeInfo = BranchNode->GetNodeInfoAs<UNarrativeBranchNodeInfo>();
	if (!BranchNodeInfo)
	{
		return SNullWidget::NullWidget;
	}

	if (!BranchNodeInfo->Condition)
	{
		return SNew(SVerticalBox)
			+ SVerticalBox::Slot()
			.VAlign(VAlign_Center)
			.FillContentHeight(50)
			[
				SNew(STextBlock)
					.Text(FText::FromString(TEXT("NO CONDITION")))
					.TextStyle(FAppStyle::Get(), "NormalText")
					.Font(FSlateFontInfo(FCoreStyle::GetDefaultFont(), 12, "Bold"))
					.ColorAndOpacity(FSlateColor(FLinearColor(1.0f, 0.05f, 0.05f, 1.0f)))
			];
	}

	return SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(FMargin(0, 5, 0, 5))
		[
			SNew(STextBlock)
				.Text(FText::FromString(TEXT("CONDITION")))
				.TextStyle(FAppStyle::Get(), "NormalText")
				.Font(FSlateFontInfo(FCoreStyle::GetDefaultFont(), 12, "Bold"))
				.ColorAndOpacity(FSlateColor(FLinearColor(1.0f, 0.75f, 0.05f, 1.0f)))
		]

		+ SVerticalBox::Slot()
		.AutoHeight()
		.FillContentHeight(50)
		[
			SNew(STextBlock)
				.Text(BranchNodeInfo->Condition->GetBranchNodeText(BranchNodeInfo->bInverse))
				.Font(FSlateFontInfo(FCoreStyle::GetDefaultFont(), 10, "Bold"))
		];
}
