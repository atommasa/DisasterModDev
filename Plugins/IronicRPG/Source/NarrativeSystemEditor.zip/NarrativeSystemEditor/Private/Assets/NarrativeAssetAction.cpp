// Copyright Ironic Studio. All Rights Reserved.


#include "Assets/NarrativeAssetAction.h"
#include "NarrativeAsset.h"
#include "Assets/NarrativeAssetEditorApp.h"
#include "Narrative/Dialogue.h"

NarrativeAssetAction::NarrativeAssetAction(EAssetTypeCategories::Type Category)
{
	AssetCategory = Category;
}

UClass* NarrativeAssetAction::GetSupportedClass() const
{
	return UDialogueBlueprint::StaticClass();
}

void NarrativeAssetAction::OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<class IToolkitHost> EditWithinLevelEditor)
{
	// Check if the EditWithinLevelEditor is valid
	EToolkitMode::Type Mode = EditWithinLevelEditor.IsValid() ? EToolkitMode::WorldCentric : EToolkitMode::Standalone;

	// [Step 2] ��l�Ʀۭq�s�边
	TSharedRef<NarrativeAssetEditorApp> Editor = MakeShared<NarrativeAssetEditorApp>();
	TArray<UBlueprint*> NarrativeBlueprints; // Array to hold the selected blueprints

	for (UObject* Object : InObjects) // Iterate through the selected objects
	{
		UE_LOG(LogTemp, Warning, TEXT(">>> Trying to open asset of type: %s"), *Object->GetClass()->GetName());

		// �p�G�ǤJ���O Blueprint �겣�A�������}�s�边
		if (UDialogueBlueprint* NarrativeBlueprint = Cast<UDialogueBlueprint>(Object))
		{
			// [Step 1] �ˬd�O�_�� parent class�A�_�h�]�m�w�] ParentClass
			if (!NarrativeBlueprint->ParentClass || NarrativeBlueprint->ParentClass == UObject::StaticClass())
			{
				NarrativeBlueprint->ParentClass = UDialogue::StaticClass(); // �A�Q���w�����O
			}

			// [Step 3] �إߤϦV�ޥΡ]�i��^
			NarrativeBlueprints.Add(NarrativeBlueprint); // Add the blueprint to the array
			NarrativeBlueprint->EditorApp = Editor;
		}
	}

	Editor->InitBlueprintEditor(Mode, EditWithinLevelEditor, NarrativeBlueprints, false);
}
